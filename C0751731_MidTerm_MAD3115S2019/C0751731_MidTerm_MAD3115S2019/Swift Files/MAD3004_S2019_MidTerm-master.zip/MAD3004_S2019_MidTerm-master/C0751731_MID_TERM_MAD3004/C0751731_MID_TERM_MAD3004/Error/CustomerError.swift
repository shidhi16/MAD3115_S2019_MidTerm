//
//  Error.swift
//  C0751731_MID_TERM_MAD3004
//
//  Created by Vijender Singh on 2019-06-21.
//  Copyright © 2019 Shivani Dhiman. All rights reserved.
//

import Foundation
enum CustomerError : Error
{
    case invalidEmail
    case invalidMobileNo
}
