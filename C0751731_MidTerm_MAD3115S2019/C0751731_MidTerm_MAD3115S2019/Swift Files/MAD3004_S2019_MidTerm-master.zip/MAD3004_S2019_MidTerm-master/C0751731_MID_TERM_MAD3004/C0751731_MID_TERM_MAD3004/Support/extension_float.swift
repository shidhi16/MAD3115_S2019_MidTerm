//
//  extension_float.swift
//  C0751731_MID_TERM_MAD3004
//
//  Created by Vijender Singh on 2019-06-20.
//  Copyright © 2019 Shivani Dhiman. All rights reserved.
//

import Foundation

extension Float
{
    public func currency() -> String
        
    {
       return String.init(format: "$%0.2f", self)
        
    }
    
}
