//
//  BillType.swift
//  C0751731_MID_TERM_MAD3004
//
//  Created by Vijender Singh on 2019-06-20.
//  Copyright © 2019 Shivani Dhiman. All rights reserved.
//

import Foundation

enum BillType
{
    case Mobile
    case Internet
    case Hydro
}
